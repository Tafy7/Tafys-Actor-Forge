# DnD Library — LEGGIMI

Archivio personale e libreria di consultazione per i progetti D&D: Actor Forge,
modulo Nightfell, campagna *Descent into Avernus*, macro. Vive sui PC (sincronizzata
con Google Drive), non nel progetto Claude: lì resta solo il piano
("DnD Library - Piano"), così lo spazio del progetto non si satura.

Ambiente di riferimento: **Foundry VTT 13 (build 351) · dnd5e 5.3.3** ·
Midi-QOL, DAE, Active Auras, Sequencer, Item Piles, Chris's Premades (CPR).

---

## Mappa

| Cartella | Cosa contiene | Chi ci scrive |
|---|---|---|
| `_indice/` | Cataloghi generati (mostri, incantesimi, oggetti, feature, manuali) | solo il distillatore |
| `_strumenti/` | Distillatore e script | Claude |
| `Inbox/` | Roba appena arrivata, da smistare | tutti; si svuota spesso |
| `Fonti/5e-2014/`, `Fonti/5e-2024/` | `Manuali/` e `Avventure/` (PDF), `Export-Foundry/` (export grezzi), `Golden/` (esemplari distillati) | Utente: PDF ed export · Claude: `Golden/` |
| `Fonti/Nightfell/`, `Heliana/`, `Amellwind/` | `Manuali/`, `Export-Foundry/`, `Regole.md` (scheda meccanica) | Utente: PDF ed export · Claude: `Regole.md` |
| `Riferimenti/CPR/` | Esempi di oggetti passati dal medikit di Chris's Premades | utente |
| `Progetti/` | Il nostro lavoro: Actor-Forge, Modulo-Nightfell, Campagna-Avernus, Macro | utente e Claude |

## Regole della casa

1. **Gli originali non si toccano.** `Manuali/`, `Avventure/` ed `Export-Foundry/`
   per Claude sono **sola lettura**. Le elaborazioni vanno in `Golden/`, `_indice/`,
   `Regole.md` o `Progetti/`.
2. **Prima l'indice.** Per trovare qualcosa, Claude legge `_indice/` e apre i file
   grandi solo dopo, nel punto giusto.
3. **Nomi dei file creati da noi**: minuscoli, con trattini, senza accenti
   (`mostri-2014.json`, `regole-spirito.md`). I manuali tengono il loro nome originale.
4. **Le schede `Regole.md`** si scrivono in forma tecnica (risorse, valori, tabelle,
   interazioni utili all'automazione), non sono copie del manuale. Una volta riviste
   insieme sono la specifica unica per i moduli e per le modalità del Forge.
5. **Il Forge è pubblico**: niente testi o contenuti dei manuali finiscono nel suo
   repository. Da qui il Forge impara solo la *struttura* dei dati.

## Sincronizzazione (Google Drive per desktop)

- Imposta Drive su **"Rispecchia file"** (*Mirror files*): i file stanno davvero
  sul disco del PC. Con "Streaming" la cartella è un'unità virtuale (es. `G:`) e
  Claude potrebbe non riuscire a leggerla, come accadeva con l'unità di rete `Z:`.
- Se usi lo streaming, segna almeno questa cartella **"Disponibile offline"**.
- Non modificare lo stesso file da due PC prima che Drive abbia sincronizzato:
  nascono copie in conflitto.

## Come usarla con Claude

- In una sessione Cowork: **Aggiungi cartella → DnD Library**.
- Le chat normali e il telefono non vedono questa cartella: se serve un file lì,
  si allega alla chat.

## Registro
- 06/11/2026 — struttura creata.
