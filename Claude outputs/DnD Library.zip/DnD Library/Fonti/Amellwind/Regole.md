# Amellwind's Guide to Monster Hunting — Scheda meccanica

> Stato: **vuota**. Si compila quando lavoreremo su questa ambientazione,
> partendo dal manuale in `Manuali/`. Forma tecnica, non copia del manuale.

## 1. In breve
<!-- Cosa cambia rispetto a 5e/5.5, in 3–5 righe. -->

## 2. Risorse nuove
<!-- Per ogni risorsa (es. materiali o parti di mostro): dove vive (arma, personaggio, mostro),
     valore iniziale/massimo, come si guadagna, come si perde, quando si ricarica. -->

| Risorsa | Dove | Max | Guadagno | Perdita | Ricarica |
|---|---|---|---|---|---|

## 3. Regole e interazioni
<!-- Una regola per punto, con i numeri. Casi limite e interazioni con le regole base. -->

## 4. Mostri
<!-- Cosa aggiungono i mostri di questa ambientazione (es. parti raccoglibili,
     meccaniche di caccia). Tabelle per CR se esistono. -->

## 5. Oggetti, armi, incantesimi
<!-- Proprietà nuove, regole di creazione o potenziamento. -->

## 6. Automazione in Foundry
<!-- Come la rappresentiamo: risorse/flag, Active Effects (DAE), Midi-QOL,
     macro. È la parte che userà il Forge (modalità Amellwind) e il modulo. -->

| Meccanica | Dato in Foundry | Modulo / tecnica | Note |
|---|---|---|---|

## 7. Domande aperte
-

## Registro
- 06/11/2026 — modello creato.
