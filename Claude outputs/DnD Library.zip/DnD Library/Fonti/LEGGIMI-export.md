# Come riempire `Export-Foundry/`

Gli export si fanno con la macro **Actor Forge — Importa / Esporta** (scheda 📤 Esporta).

1. **Sorgente** → *Compendi* → scegli il compendio (es. i mostri del Monster Manual).
2. **Cartella** → *tutto il compendio*, con **Includi le sottocartelle** spuntato.
3. **Formato** → **File unico (.json)**: per la libreria è il più comodo da analizzare.
4. **Nome del file** → usa i nomi qui sotto.
5. Sposta il file scaricato nella cartella `Export-Foundry/` del sistema giusto.

## Nomi dei file

| Contenuto | 2014 → `Fonti/5e-2014/Export-Foundry/` | 2024 → `Fonti/5e-2024/Export-Foundry/` |
|---|---|---|
| Mostri | `mostri.json` | `mostri.json` |
| Incantesimi | `incantesimi.json` | `incantesimi.json` |
| Oggetti (armi, armature, magici, consumabili…) | `oggetti.json` | `oggetti.json` |
| Feature di classe e sottoclasse | `feature-classi.json` | `feature-classi.json` |
| Talenti | `talenti.json` | `talenti.json` |
| Specie / razze e background | `origini.json` | `origini.json` |
| Classi | `classi.json` | `classi.json` |

- Se un contenuto è diviso in più compendi (es. un manuale per compendio), aggiungi
  la sigla: `mostri-mm.json`, `mostri-mpmm.json`, `incantesimi-xgte.json`.
- Le ambientazioni (Nightfell, Heliana, Amellwind) seguono gli stessi nomi nella
  loro `Export-Foundry/`, se esistono compendi Foundry per quei manuali.
- File molto grandi: va bene lo stesso, il distillatore li legge direttamente sul PC.
