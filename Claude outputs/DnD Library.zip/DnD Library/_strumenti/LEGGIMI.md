# _strumenti

Script di Claude per la libreria (in arrivo: il **distillatore**, che analizza gli export in `Fonti/*/Export-Foundry/`, scrive i cataloghi in `_indice/` e gli esemplari in `Fonti/*/Golden/`).
Girano direttamente su questo PC: niente upload dei file grandi.
