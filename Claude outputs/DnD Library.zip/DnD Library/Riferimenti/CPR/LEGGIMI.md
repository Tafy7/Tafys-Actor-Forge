# Esempi Chris's Premades (CPR)

Servono a capire **quali dati scrive CPR** quando il medikit automatizza un oggetto,
così il Forge può produrre oggetti che CPR riconosce dopo l'import.
Non serve passare dal medikit interi compendi: bastano una decina di esempi vari.

## Cosa esportare (circa 10 oggetti, già passati dal medikit)

- [ ] 1 incantesimo d'attacco (es. *Firebolt* / *Dardo di fuoco*)
- [ ] 1 incantesimo a tiro salvezza con area (es. *Fireball*)
- [ ] 1 incantesimo di concentrazione con effetto (es. *Bless* / *Hex*)
- [ ] 1 arma (es. spada lunga)
- [ ] 1 arma magica con proprietà speciale
- [ ] 1 feature di classe con risorsa (es. *Action Surge* / *Rage*)
- [ ] 1 feature passiva con effetto
- [ ] 1 talento
- [ ] 1 azione di mostro (es. *Multiattack* o un soffio)
- [ ] 1 oggetto consumabile (es. pozione)

## Come

1. Metti gli oggetti (già passati dal medikit) in una cartella del mondo, es. `CPR-esempi`.
2. Macro Importa / Esporta → 📤 Esporta → Sorgente *Oggetti* → Cartella `CPR-esempi`.
3. Formato **File unico (.json)**, nome `cpr-esempi.json`, e salvalo qui.
4. Se vuoi il confronto "prima / dopo", esporta anche le stesse voci **senza** medikit
   come `cpr-esempi-originali.json`.
