# _indice

Cataloghi **generati dal distillatore** (`_strumenti/`): mostri, incantesimi, oggetti, feature, manuali.
Non modificarli a mano: vengono riscritti a ogni passaggio del distillatore.
Claude li legge **prima** di aprire i file grandi in `Fonti/`.
